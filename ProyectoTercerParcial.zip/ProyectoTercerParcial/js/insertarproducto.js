function fechaActual(){
	var vFechaActual = new Date();

	return vFechaActual;
}